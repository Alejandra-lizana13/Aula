package excepcion;

public class ExcepcionIntervalo extends Exception {

	private static final long serialVersionUID = 1L;

	public ExcepcionIntervalo(String msg) {
        super(msg);
    }
}