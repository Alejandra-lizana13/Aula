package nuevasExcepciones3;

public class DemasiadoCalor extends Limites {
	public DemasiadoCalor(String str){
		super(str);	
	}
	public DemasiadoCalor(){
		super();	
	}	
}