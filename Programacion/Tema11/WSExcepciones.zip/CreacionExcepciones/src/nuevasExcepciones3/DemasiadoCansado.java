package nuevasExcepciones3;

public class DemasiadoCansado extends Limites {
	public DemasiadoCansado(String str){
		super(str);	
	}
	public DemasiadoCansado(){
		super();	
	}	
}