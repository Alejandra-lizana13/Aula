package nuevasExcepciones3;
public class Limites extends Exception {

	public Limites(String str){
		super(str);	
	}
	public Limites(){
		super();	
	}		
}