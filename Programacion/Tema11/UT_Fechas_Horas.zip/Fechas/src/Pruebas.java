import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;// A partir de la v8
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Date; //A partir de la v1

public class Pruebas {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Date date = new Date();
		//Caso 1: obtener la hora y salida por pantalla con formato:
		DateFormat hourFormat = new SimpleDateFormat("HH:mm:ss");
		System.out.println("Hora: "+hourFormat.format(date));
		//Caso 2: obtener la fecha y salida por pantalla con formato:
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		System.out.println("Fecha: "+dateFormat.format(date));
		//Caso 3: obtenerhora y fecha y salida por pantalla con formato:
		DateFormat hourdateFormat = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy");
		System.out.println("Hora y fecha: "+hourdateFormat.format(date) + "\n");
	
		//Date date = new Date(114, 2, 18);
		Date date1 = new Date(114, 2, 18); // Deprecated
		System.out.println(date1 + "\n");
		
		Calendar calendar = new GregorianCalendar(2014, 2, 18);
		System.out.println(calendar.getTime());

		// En Java 8:
		LocalDate date8 = LocalDate.of(1989, 11, 11); //1989-11-11
		System.out.println(date8.getYear()); //1989
		System.out.println(date8.getMonth()); //NOVEMBER
		System.out.println(date8.getDayOfMonth()); //11
		
		date8 = LocalDate.now(); 
		System.out.println(date8);
		
		LocalDateTime ldt = LocalDateTime.now(); //1989-11-11
		System.out.println(ldt);
		
		LocalTime localTime1 = LocalTime.of(12, 25);
		LocalTime localTime2 = LocalTime.of(17, 35);
		Duration duration = Duration.between(localTime1, localTime2);
		System.out.println(duration);
	}

}
