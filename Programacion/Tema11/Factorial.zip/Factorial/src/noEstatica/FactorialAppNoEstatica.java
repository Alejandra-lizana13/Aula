package noEstatica;

class FactorialNegExc extends Exception {
	private static final long serialVersionUID = 1L;
		public FactorialNegExc(String msg){		
			super(msg);
		}	
}

public class FactorialAppNoEstatica {

    double factorial(int n) throws FactorialNegExc{
    	int f=1;
		
		if(n<0)
			throw new FactorialNegExc("No se puede calcular el factorial de un n�mero negativo");
		
		for(int i=1;i<=n;i++){
			f*=i;	
		}
					
		return f;
	}
	
	public static void main(String[] args)  {

		double resultado=0;
		
		FactorialAppNoEstatica f = new FactorialAppNoEstatica();
		
		try {
			resultado = f.factorial(6);
		}
		catch (FactorialNegExc ex) {
			System.out.println ("NumeroNegativoException " + ex.getMessage());
		}
		finally {
			if (resultado != 0) System.out.println ("El resultado es " + resultado);
		}

	}

}

