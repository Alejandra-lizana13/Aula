package ejemplo3;

public class Estatica3 { 
	static int a,b; 
	//Bloque est�tico
	static{ 
		a = 10; 
		b = 20; 
	} // Si no es static no compilar�
	
	
}
