package ejemplo4;

public class Normal {
	int a, b;

	public Normal() {
		a = 10;
		b = 20;
	}

}
