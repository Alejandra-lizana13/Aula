public class Test1 {
	int atributo1;
	Test1 (int atrib) {atributo1 = 0;}
	
	public static void main (String[ ] Args) {
		System.out.println ("Mensaje 1");
		// Error, System.out.println ("Atributo 1 vale" + this.getAtrib1());
		
	} //Cierre del main
	public int getAtrib1() {return atributo1;}
} //Cierre de la clase