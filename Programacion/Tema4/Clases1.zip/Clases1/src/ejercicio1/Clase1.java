package ejercicio1;

public class Clase1 {
	private double valor=9.8; 
	private int x=7; 

	/*public Clase() {
		valor=0;
		x=0;
	}*/
	
	public void imprimir(double valor, int x){ 
		System.out.print(valor  + " " + this.x); 
	} 

}
