package ejercicio1;
public class Ejercicio {

	public static void main(String[] args) {
		Clase1 obj1=new Clase1(); 
		obj1.imprimir(24.3,5); 

	}

}
