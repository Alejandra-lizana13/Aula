package ejercicio3;
import java.util.Scanner;
class Principal{
   public static void main(String[] args){
      Scanner teclado=new Scanner(System.in);
      double x,y,r;
      
	  System.out.println("Introducir la coordenada x");
      x=teclado.nextDouble();	  
      System.out.println("Introducir la coordenada y");
	  y=teclado.nextDouble();
	  System.out.println("Introducir el radio");
      r=teclado.nextDouble();	  
      
      Circulo c1=new Circulo(x,y,r);
      System.out.println(c1);  
      
	  Circulo c2=new Circulo();
      System.out.println(c2);
	  
	  System.out.println("Introducir el radio");
      r=teclado.nextDouble();
      
	  Circulo c3=new Circulo(r);
      System.out.println(c3);
	      
	  teclado.close();
   }
}

