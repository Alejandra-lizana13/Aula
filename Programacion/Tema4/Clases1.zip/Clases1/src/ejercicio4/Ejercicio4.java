package ejercicio4;

public class Ejercicio4 {
	public static void main(String[] args) {
		
		Punto p1;
		Punto p2;
		
		p1 = new Punto();
		p2 = new Punto(3, 4);
		
		p1.escribePunto();
		p2.escribePunto();
		
		System.out.println(p1);
		System.out.println(p2);
	}
	
}
