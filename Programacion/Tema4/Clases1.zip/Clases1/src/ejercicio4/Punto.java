package ejercicio4;

public class Punto {
	private double x;
    private double y;

    /* metodos */
   	
    // Constructores
	public Punto() {
    }
	
    public Punto(double x, double y) {
      this.x = x;
      this.y = y;
    }
    
    // metodos de acceso a atributos:
    public double getX() {
      return x;
    }

    public double getY() {
      return y;
    }
    
    // meodos para poner valores en atributos:
    public void setX(double x) {
        this.x = x;
     }

    public void setY(double y) {
        this.y = y;
     }
   
     // toString: devuelve una cadena con la representacion del objeto
    public String toString() {
      // el signo + para cadenas no significa "suma matematica" sino concatenacion
      return "(" + x + ", " + y + ")";
    }
	
    public void escribePunto() {
      // el signo + para cadenas no significa "suma matematica" sino concatenacion
      System.out.println("(" + x + ", " + y + ")") ;
    }
}