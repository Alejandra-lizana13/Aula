package ejercicio2;

public class Ejercicio {
	public static void main(String[] args) {
		
		Clase1 obj1=new Clase1(5,4); 
		//p1=5
		//p2=4
		System.out.print(obj1.modificar(4)+" "); 
		//p1=9
		//p2=8
		
		Clase1 obj2=new Clase1(5,4); 
		//p1=5
		//p2=4
		System.out.print(obj2.modificar(5)+" "); 
		//p1=10
		//p2=9
		
		obj2=obj1;
		//p1=9
		//p2=8
		System.out.print(obj2.modificar(5)+" "); 
		//p1=14
		//p2=13
	}
	
}
