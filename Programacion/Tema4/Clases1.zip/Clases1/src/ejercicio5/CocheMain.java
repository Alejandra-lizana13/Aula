package ejercicio5;
public class CocheMain {
	public static void main(String args[]){
		// Creo un coche con el constructor con par�metros
		Coche cocheB = new Coche("rojo", "Volvo", "1111-ABC", 5 );
				
		cocheB.escribeCoche();
		System.out.println(cocheB);
		
		Coche cocheA = new Coche();	
		
		// Creo un coche con el constructor por defecto
		cocheA.escribeCoche();
		cocheA.ponMatricula("2222-DSD");
		cocheA.ponMarca("Nissan");
		cocheA.ponNumPuertas(4);
		cocheA.pintaCoche("verde");
		
		System.out.println("Antes de pintar");
		System.out.println(cocheA);
		cocheA.escribeCoche();	
		
		cocheA.pintaCoche("naranja");
		System.out.println("Despues de pintar de nuevo");
		System.out.println(cocheA);
		cocheA.escribeCoche();
	}
}
