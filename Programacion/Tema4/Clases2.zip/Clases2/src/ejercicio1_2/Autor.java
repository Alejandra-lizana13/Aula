package ejercicio1_2;

public class Autor {

	private String nombre;
	private String apellido;
	private int titulos_editados;

	public Autor(String nombre, String apellido, int titulos_editados) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.titulos_editados = titulos_editados;
	}

	public String toString() {
		return nombre + " " + apellido + " tiene " + titulos_editados + " titulos editados";
	}

}
