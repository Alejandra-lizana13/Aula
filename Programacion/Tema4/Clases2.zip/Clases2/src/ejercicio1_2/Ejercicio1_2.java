package ejercicio1_2;
// En esta version, autor es una instancia de una clase aparte
public class Ejercicio1_2 { 
	public static void main(String[] args){ 
		Autor autor=new Autor("Paul", "Auster", 15); 
		Libro libro=new Libro("La trilogia de Nueva York", autor); 
		System.out.println(libro);
	} 
} 

class Libro { 
	private String titulo; 
	private Autor autor; 
	
	public Libro(String titulo, Autor autor){ 
		this.titulo=titulo; 
		this.autor=autor; 
	}
	
	public Autor getAutor(){ 
		return autor; 
	}
	 
	public String getTitulo(){ 
		return titulo; 
	} 
	
	public String toString(){ 
		return "Autor\t" + autor + "\nTitulo\t" +  titulo; 
	} 
} 



