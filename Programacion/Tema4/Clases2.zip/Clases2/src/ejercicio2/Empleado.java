package ejercicio2;
/**
 * Clase Empleado
 *
 * Contiene informacion de cada empleado
 *

 */
 public class Empleado {
	//Atributos
	/**
	 * Nombre del empleado
	 */
	private String nombre;
	/**
	 * Apellido del empleado
	 */
	private String apellido;
	/**
	 * Edad del empleado
	 */
	private int edad;
	/**
	 * Salario del empleado
	 */
	private double salario;
	//Constructores
         /**
	 * Constructor por defecto
	 */
	public Empleado(){
		/*this.nombre="";
		this.apellido="";
		this.edad=0;
		this.salario=0;*/
	}
         /**
	 * Constructor con 4 parametros
	 * @param nombre nombre del empleado
	 * @param apellido nombre del empleado
	 * @param edad edad del empleado
	 * @param salario salario del empleado
	 */
	public Empleado(String nombre, String apellido, int edad, double salario){
		this.nombre=nombre;
		this.apellido=apellido;
		this.edad=edad;
		this.salario=salario;
	}
	//Metodos getter setter
	public String getNombre(){
		return nombre;
	}
	public void putNombre(String nombre){
		this.nombre = nombre;
	}
	public String getApellido(){
		return apellido;
	}
	public void putApellido(String apellido){
		this.apellido = apellido;
	}
	public int getEdad(){
		return edad;
	}
	public void putEdad(int edad){
		this.edad = edad;
	}
	public double getSalario(){
		return salario;
	}
	public void putSalario(double salario){
		this.salario = salario;
	}
	
     /**
	 * Suma un plus al salario del empleado si el empleado tiene mas de 40 a�os
	 * @param sueldoPlus
	 *
	 */
	public boolean plus (double sueldoPlus){
		boolean aumento=false;
                if (edad>40){
                	salario+=sueldoPlus;
                	aumento=true;
                }
                return aumento;
	}
	
	public String toString(){
		return "Nombre " + nombre + " Apellido " + apellido + " Edad " + edad + " Salario " + salario;
	}
}