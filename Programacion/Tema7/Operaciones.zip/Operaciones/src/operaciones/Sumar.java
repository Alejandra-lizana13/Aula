package operaciones;

public class Sumar {
float x, y;
	public Sumar(float _x, float _y) {
		x = _x;
		y = _y;
	}
	
	public void suma() {
		System.out.println(x+y);
	}
}
