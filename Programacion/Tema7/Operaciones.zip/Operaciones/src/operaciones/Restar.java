package operaciones;

public class Restar {
float x, y;
	public Restar(float _x, float _y) {
		x = _x;
		y = _y;
	}
	
	public void resta() {
		System.out.println(x-y);
	}
}
