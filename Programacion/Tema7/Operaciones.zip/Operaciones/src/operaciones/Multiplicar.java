package operaciones;

public class Multiplicar {
float x, y;
	public Multiplicar(float _x, float _y) {
		x = _x;
		y = _y;
	}
	
	public void multiplica() {
		System.out.println(x*y);
	}
}
