package operaciones;

public class Dividir {
float x, y;
	public Dividir(float _x, float _y) {
		x = _x;
		y = _y;
	}
	
	public void divide() {
		System.out.println(x/y);
	}
}
