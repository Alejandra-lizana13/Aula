package resultados;
import operaciones.*;

public class Calcular {
	
	public static void main(String[] args) {
		
		IntroducirNumeros intro = new IntroducirNumeros();
		
		Sumar sum = new Sumar(intro.i, intro.j);
		sum.suma();
		
		new Sumar(intro.i, intro.j).suma();
		
		new Restar(intro.i, intro.j).resta();
		new Multiplicar(intro.i, intro.j).multiplica();
		new Dividir(intro.i, intro.j).divide();
	}

}
