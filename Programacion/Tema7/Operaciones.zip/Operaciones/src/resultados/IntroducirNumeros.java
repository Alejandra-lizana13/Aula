package resultados;

public class IntroducirNumeros {
	float i, j;

	public IntroducirNumeros() {
		java.util.Scanner teclado = new java.util.Scanner(System.in);
		
		System.out.println("Introduce un valor");
		i = teclado.nextFloat();
		System.out.println("Introduce otro valor");
		j = teclado.nextFloat();
	}

}
