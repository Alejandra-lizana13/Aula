
public class PreEj32 {
	public static void main(String[] args) {
		 for(int i=0;i<=9;i++)
			 for(int j=0;j<=9;j++) 
				 for(int k=0;k<=9;k++){				
					 System.out.print(i + " " + j + " " + k);
	
					 System.out.println();
				 }			 
	       }
}
