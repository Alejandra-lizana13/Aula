

public class Prueba6 {
	public static void main(String[] args) {
		
		double numero = 3.456778;
			
		numero = (double)Math.round(numero*100)/100;
		
		System.out.println("Numero con 2 decimales " + numero);
				
	 }
	
}
