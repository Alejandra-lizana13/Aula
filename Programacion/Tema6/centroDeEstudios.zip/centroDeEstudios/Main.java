package centroDeEstudios;
import java.util.*;
public class Main{
	public static void main(String[] args){
		
		ArrayList <CentroDeEstudios> centros= new ArrayList<CentroDeEstudios>();
		
		Concertado conc = new Concertado("Juan de Valdes", "Alcala 32", 300, 12000);
		System.out.println(conc);
		
		
		Privado priv = new Privado("Montessori", "Gregorio Benitez", 700);
		System.out.println(priv);
		
		Publico pub = new Publico("Julian Marias", "Budapest", 2500);
		System.out.println(pub);
		
		centros.add(conc);
		centros.add(priv);
		centros.add(pub);
		
		System.out.println();
		
		for (int i=0; i<centros.size(); i++)
			System.out.println(centros.get(i));
	}
}