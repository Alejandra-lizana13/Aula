package centroDeEstudios;
public class Concertado extends CentroDeEstudios{
	private int cuotaMensual;
	private int asignacPubMensual;
	
	public Concertado(String nombre, String direccion, int _cuotaMensual, 
	int _asignacPubMensual){
		super(nombre, direccion);
		cuotaMensual = _cuotaMensual;
		asignacPubMensual = _asignacPubMensual;
	}
	
	public String toString() {
		String s = super.toString();
        s += " Cuota Mensual: " + cuotaMensual + " " +
        " Asignacion Mensual: " +  asignacPubMensual;
        
        return s;
    }
}
