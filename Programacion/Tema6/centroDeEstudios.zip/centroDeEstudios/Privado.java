package centroDeEstudios;
public class Privado extends CentroDeEstudios{
	private int cuotaMensual;
	
	public Privado(String _nombre, String _direccion, int _cuotaMensual){
		super(_nombre, _direccion);
		cuotaMensual = _cuotaMensual;
	}
	
	public String toString() {
		String s = super.toString();
		
        s += " Cuota Mensual: " + cuotaMensual + "\n";
        
        return s;
    }
}
