package centroDeEstudios;

public class Publico extends CentroDeEstudios{
	private int asignacionAnual;
	
	public Publico(String _nombre, String _direccion, int _asignacionAnual){
		super(_nombre, _direccion);
		asignacionAnual = _asignacionAnual;
	}
	
	public String toString() {
		String s = super.toString();
		
        s += " Asignacion Anual: " +  asignacionAnual;
        
        return s;
    }
}