package centroDeEstudios;
public class CentroDeEstudios {
    String nombre;
    String direccion;
    
    public CentroDeEstudios(String _nombre, String _direccion) {
        this.nombre = _nombre;
        this.direccion = _direccion;
    }

    public void setNombre(String _nombre) {
        this.nombre = _nombre;
    }

    public void setDireccion(String _direccion) {
        this.direccion = _direccion;
    }
    
    public String getDireccion() {
        return this.direccion;
    }
    
    public String getNombre() {
        return this.nombre;
    }
    
    public String toString() {
        return " Nombre: " + nombre + " " +" Direccion: " + direccion;
    }
    
}
