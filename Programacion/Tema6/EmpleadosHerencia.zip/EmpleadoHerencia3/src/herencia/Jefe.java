package herencia;
public class Jefe extends Empleado {
    protected String departamento;

    public Jefe (String n, int s, String dep) {
        super(n,s);
        departamento= dep;
    }

    public void cambiarDepartamento(String dep) {
        departamento= dep;
    }

    public String toString() {
        String s = super.toString();
        s = s + "\n" + " Departamento: " + departamento;
        
        return s;
    }
}