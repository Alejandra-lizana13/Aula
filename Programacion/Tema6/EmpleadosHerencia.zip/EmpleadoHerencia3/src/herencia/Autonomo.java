package herencia;
public class Autonomo extends Empleado {
    protected String empresa;

    public Autonomo (String n, int s, String emp) {
        super(n,s);
        empresa= emp;
    }

    public void cambiarEmpresa(String emp) {
        empresa= emp;
    }

    public String toString() {
        String s = super.toString();
        s = s + "\n" + " empresa: " + empresa;
        
        return s;
    }
}
