package herencia;

import otro.Ejecutivo;

public class Empleado {
	protected String nombre;
    protected int numEmpleado, sueldo;

    static private int contador = 0;
    
    public Empleado(String nombre, int sueldo) {
        this.nombre = nombre;
        this.sueldo = sueldo;
        numEmpleado = ++contador;
    }

    // void aumentarSueldo(int porcentaje) {
    // Si quito el modificador protected, un ejecutivo no podr� acceder al
    // m�todo aumentarSueldo.
     protected void aumentarSueldo(int porcentaje) {
        sueldo += (int)(sueldo * porcentaje / 100);
    }
    
    public String toString() {
        return " Num. empleado " + numEmpleado + "\n" + " Nombre: " + nombre
                + "\n" +" Sueldo: " + sueldo;
    }

    public String tipoEmpleado() {
    	String tipo;
    	
	    if (this instanceof Ejecutivo)
	    	tipo = "Es ejecutivo";	
	    else if (this instanceof Autonomo)
	    	tipo = "Es autonomo";
	    else if (this instanceof Jefe)
	    	tipo = "Es jefe";
	    else
	    	tipo = "Es empleado";
	    
	    return tipo;
    }
    
   public void esJefe() {
		if (this instanceof Jefe){
			Jefe j=(Jefe)this;

			System.out.println("\nEs jefe del departamento " + j.departamento);
		}
		else 
			System.out.println("No es jefe ");
		
	}
	
	
    
}
