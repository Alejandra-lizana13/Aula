package herencia;

public class EmpresaApp{
	
	public static void main(String[] args){	
		Empleado emp = new Empleado ("Pepe Gotera" , 1200) ;
		System.out.println(emp);
		// Se puede invocar porque es protegida si est� en el mismo paquete 
		// o en una clase que hereda de la clase donde est� definida
		emp.accesoAumentarSueldo(10);
		System.out.println(emp);
		System.out.println();
				
		Ejecutivo ejec = new Ejecutivo("Armando Mucho", 3000);
		ejec.asignarPresupuesto(15000);
		ejec.accesoAumentarSueldo(5);
		// Se puede invocar porque es protegida si est� en el mismo paquete 
		// o en una clase que hereda de la clase donde est� definida
	    System.out.println(ejec);
	    
	    Ejecutivo ejec1 = new Ejecutivo("Luis L�pez", 2000, 12000);
	    System.out.println(ejec1);
		
		Autonomo auto = new Autonomo("Auto Nomo", 200, "MegaTrix");
		System.out.println(auto);
		
		System.out.println();
		
		Jefe jefecillo = new Jefe("Jefe Cillo", 200, "Finanzas");
		System.out.println(jefecillo);
		
		System.out.println();
		
		System.out.println(ejec);
		System.out.println(ejec.tipoEmpleado());
		ejec.esJefe();
		
		System.out.println();
		
		System.out.println(auto);
		System.out.println(auto.tipoEmpleado());
		auto.esJefe();
		
		System.out.println();
		
		System.out.println(emp);
		System.out.println(emp.tipoEmpleado());
		emp.esJefe();
		
		System.out.println();
		
		System.out.println(jefecillo);
		System.out.println(jefecillo.tipoEmpleado());
		jefecillo.esJefe();

		
	}	 
}

