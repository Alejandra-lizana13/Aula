package herencia;

public class Ejecutivo extends Empleado {
    protected int presupuesto;

    public Ejecutivo (String n, int s) {
        super(n,s);
    }

	public Ejecutivo (String n, int s, int p) {
        super(n,s);
        presupuesto=p;
    }
    
    public void asignarPresupuesto(int p) {
        presupuesto = p;
    }
    
    public void usaMetodo() {
		new Ejecutivo("Pepe" , 2000).accesoAumentarSueldo(8);
    	super.accesoAumentarSueldo(8);
    }
    
    public String toString() {
        String s = super.toString();
        s = s + "\n" + " Presupuesto: " + presupuesto;
        
        return s;
    }
}

