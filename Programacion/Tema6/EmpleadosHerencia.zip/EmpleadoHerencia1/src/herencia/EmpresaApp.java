package herencia;

public class EmpresaApp{
	
	public static void main(String[] args){
		// Descomentar y probar:
		Empleado emp = new Empleado ( "Esteban Comex Plota" , 1000) ;
		System.out.println(emp);
		//emp.asignarPresupuesto(5000);  // error, es un metodo del hijo: Ejecutivo
		
		System.out.println();
		Empleado emp1 = new Empleado ("Pepe Gotera" , 1200) ;
		System.out.println(emp1);
		emp1.aumentarSueldo(10);
		System.out.println();
		
		System.out.println(emp1);
		System.out.println();
		
		Ejecutivo ejec = new Ejecutivo();
		System.out.println(ejec);
		
		// No hay constructor para ejecutivo, hay que crearlo en la siguiente version:
		//Ejecutivo ejec = new Ejecutivo("Armando Mucho", 3000); // Esto da error
		//ejec.asignarPresupuesto(1500);
		//ejec.aumentarSueldo(5);
	    // System.out.println(ejec);
	}	
}