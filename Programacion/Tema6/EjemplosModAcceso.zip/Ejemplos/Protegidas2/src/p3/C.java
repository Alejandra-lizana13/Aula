// Programa Java para ilustrar
// el modificador protected
package p3;

// importar todas las clases en el paquete p1
import p1.*;
import p2.*;

public class C {
    public static void main(String[] args) {
        B obj = new B();
        obj.mostrar(); // Esta en una clase que no hereda de A donde esta definido el metodo protegido
        // no importa que la clase herede de la clase que tiene el metodo protegido, sino donde se invoca
    }
}