// Programa Java para ilustrar
// el modificador protected
package p1;

public class A {
    protected void mostrar(){
        System.out.println("Java ejemplo");
    }
}