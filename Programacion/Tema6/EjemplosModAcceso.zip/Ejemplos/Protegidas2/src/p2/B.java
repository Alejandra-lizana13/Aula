// Programa Java para ilustrar
// el modificador protected
package p2;

// importar todas las clases en el paquete p1
import p1.*;

public class B extends A {
    
}