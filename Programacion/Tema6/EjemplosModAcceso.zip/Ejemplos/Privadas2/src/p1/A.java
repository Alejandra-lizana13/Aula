// Programa Java para ilustrar el error
// al usar la clase desde un mismo paquete
// con modificador private
package p1;

public class A {
    private void mostrar() {
        System.out.println("Ejemplo modificadores Java ");
    }
}
