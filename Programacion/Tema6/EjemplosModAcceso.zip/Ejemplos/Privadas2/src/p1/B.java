// Programa Java para ilustrar el error
// al usar la clase desde un mismo paquete
// con modificador private
package p1;

public class B {
    public static void main(String[] args) {
        A obj= new A();
        //tratando de acceder al método privado de otra clase
        obj.mostrar();
    }

}