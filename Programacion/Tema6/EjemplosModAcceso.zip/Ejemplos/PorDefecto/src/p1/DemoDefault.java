// Programa Java para ilustrar el modificador default
package p1;

// La clase DemoDefault tiene modificador de acceso default
class DemoDefault {
    void mostrar()
    {
        System.out.println("Hola Mundo!");
    }
}