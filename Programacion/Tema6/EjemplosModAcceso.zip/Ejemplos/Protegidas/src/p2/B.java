// Programa Java para ilustrar
// el modificador protected
package p2;

// importar todas las clases en el paquete p1
import p1.*;

public class B extends A {
    public static void main(String[] args) {
        B obj = new B();
        obj.mostrar(); // Esta en una clase que hereda de A donde esta definido el metodo protegido
    }
}