// Programa Java para ilustrar
// el modificador public
package p1;

public class A {
    public void mostrar(){
        System.out.println("Java desde Cero");
    }
}