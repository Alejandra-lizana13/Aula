public interface MiInterfaz {
	public int CONSTANTE = 100; // No puede ser ni privada ni protected, siempre final y est�tica

	int metodoAbstracto(int parametro); // No puede ser ni privada ni protected
}
