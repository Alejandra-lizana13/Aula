public interface Figura{ 
	int area();
}
