public interface Conducible {
	int MAXIMO_GIRO = 90;

	void girarIzquierda(int grados);

	void girarDerecha(int grados);
}