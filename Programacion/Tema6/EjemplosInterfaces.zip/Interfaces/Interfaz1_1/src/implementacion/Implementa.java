package implementacion;

import definicion.X;

public class Implementa implements X {
	public void getMax()
	{
		System.out.println(MAX);
	}
}