package main;
import implementacion.Implementa;

public class Ejemplo {
	public static void main(String args[]) {
		Implementa ob = new Implementa();

		ob.getMax();
		//ob.MAX=9;
	}
}