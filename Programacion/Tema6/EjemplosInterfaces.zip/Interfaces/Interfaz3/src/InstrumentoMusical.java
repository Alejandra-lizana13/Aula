interface InstrumentoMusical {
	void tocar();

	void afinar();

	String tipoInstrumento();
}
