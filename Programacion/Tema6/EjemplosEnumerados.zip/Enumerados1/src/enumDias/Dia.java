package enumDias;

//Una clase enum

enum Dia
{
 LUNES, MARTES, MIERCOLES, JUEVES,
 VIERNES, SABADO, DOMINGO;
}

