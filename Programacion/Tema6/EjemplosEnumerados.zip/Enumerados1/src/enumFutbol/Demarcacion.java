package enumFutbol;

public enum Demarcacion
{
	PORTERO, DEFENSA, CENTROCAMPISTA, DELANTERO
}

// PORTERO, DEFENSA, CENTROCAMPISTA, DELANTERO son objetos de la clase enumerada Demarcacion