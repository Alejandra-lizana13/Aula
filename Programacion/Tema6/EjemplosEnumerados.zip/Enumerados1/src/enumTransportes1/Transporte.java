package enumTransportes1;
//Una enumeraci�n de transporte

enum Transporte{
  COCHE, CAMION, AVION, TREN, BARCO;
}