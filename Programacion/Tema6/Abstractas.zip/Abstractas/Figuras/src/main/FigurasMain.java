package main;

import figuras.Poligono;
import figuras.Rectangulo;
import figuras.Triangulo;

public class FigurasMain {
 public static void main(String args[]){
	 
	 Triangulo t = new Triangulo(3.25, 4.55, 2.71);
     System.out.printf("�rea del tri�ngulo: %.2f %n", t.area());
     
     Rectangulo r = new Rectangulo(5.70,2.29);
     System.out.printf("�rea del rect�ngulo: %.2f %n", r.area()); 
     
     Poligono p;   
     Triangulo tr = new Triangulo(3.25, 4.55, 2.71);
     p = tr;
     p.area(); // Imprime el �rea de un tri�ngulo
     
     Poligono po = new Triangulo(3.25, 4.55, 2.71);  //upcasting
     Triangulo tri;
     tri = (Triangulo) po; //downcasting
     
     System.out.printf("�rea del pol�gono: %.2f %n", tri.area()); 
     System.out.printf("�rea del pol�gono: %.2f %n", p.area()); 
 }
}
