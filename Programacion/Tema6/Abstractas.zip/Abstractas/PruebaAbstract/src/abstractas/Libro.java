package abstractas;

public class Libro extends Item {

	public boolean esAlquilable() {
		return false;
	}
}

