package abstractas;

public class Pelicula extends Item {
    
	public boolean esAlquilable() {
        return true;
    }
}