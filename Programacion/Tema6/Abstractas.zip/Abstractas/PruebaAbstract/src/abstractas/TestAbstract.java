package abstractas;

public class TestAbstract {
    public static void main (String[] args) {
        Pelicula pelicula = new Pelicula();
        Libro libro = new Libro();
        
        System.out.println(pelicula.esAlquilable());
        System.out.println(pelicula.getPrecio());
        System.out.println(libro.esAlquilable());
        System.out.println(libro.getPrecio());
    }
}