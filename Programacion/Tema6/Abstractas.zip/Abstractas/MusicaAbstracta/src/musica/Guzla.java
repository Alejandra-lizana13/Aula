package musica;
// Un tipo de Guitarra 
public class Guzla extends Guitarra {
       public void tocar() {
         System.out.println("Guzla.tocar()");
       }
       public void afinar() {
         System.out.println("Guzla.afinar()");
       }
}
