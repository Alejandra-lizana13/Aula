package herencia1;

public class Milpies {
	protected int numeroDePies;
	
	public Milpies(){
		numeroDePies = 1000;
		escribePies();
	}
	
	public void escribePies(){
		System.out.println("Un Milpi�s o Cochinilla tiene " + numeroDePies + " pies");
	}
}