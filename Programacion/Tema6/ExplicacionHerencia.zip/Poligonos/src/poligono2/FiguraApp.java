package poligono2;

public class FiguraApp {
	public static void main(String args[])
	{
			Triangulo t = new Triangulo("Hola");
			// Llama tambi�n al constructor de padre y abuelo
			t.Dibujar();
			
			/*
			Poligono p = new Poligono();
			// Llama tambi�n al constructor del padre
			p.Dibujar();
			
			Figura f = new Figura();
			f.Dibujar();
			*/
	}
}
