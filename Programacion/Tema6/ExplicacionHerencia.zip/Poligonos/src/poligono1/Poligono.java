package poligono1;
public class Poligono extends Figura
{
	public Poligono()
	{
		System.out.println("Poligono()");
	}
	public void Dibujar()	{
		System.out.println("Dibujo Poligono");
	}
}
