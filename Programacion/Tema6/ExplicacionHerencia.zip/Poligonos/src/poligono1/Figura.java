package poligono1;
public class Figura
{
	public Figura(){
		System.out.println("Figura()");
	}
	public void Dibujar()	{
		System.out.println("Dibujo Figura");
	}
}
