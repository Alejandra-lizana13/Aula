package musica;
// Ejemplo de implementacion de herencia
public class Musica {
	public static final int NUM_INST = 5;
	
    // No importa el tipo de Instrumento,
    // seguir� funcionando debido a Polimorfismo:
    public static void afinar(Instrumento i) {	
		i.tocar(); //Saldran todas, pues tocar lo tienen todas implementado
		i.afinar();
		// Solo saldra Guzla, que es la unica que tiene este metodo implementado
    }
    
	public static void devolverTipo(Instrumento i) {	
		System.out.println("tipo devuelto " + i.tipo()); 	
    }
    
    public static void afinarTodo(Instrumento[] inst) {
	
		for (int i = 0; i < inst.length; i++)
	    	afinar(inst[i]);
	    	
    }
    
    public static void obtTipos(Instrumento[] inst) {
	
		for (int i = 0; i < inst.length; i++)
	    	devolverTipo(inst[i]);	    	
    }

    public static void main(String[] args) {
		Instrumento orquesta []= new Instrumento[NUM_INST];
		int i = 0;
		
		orquesta[i++] = new Guitarra();
		orquesta[i++] = new Piano();
		orquesta[i++] = new Saxofon();
		orquesta[i++] = new Guzla();
		orquesta[i++] = new Ukelele();
		
		afinarTodo(orquesta);
		
		// Guzla no tiene tipo() por lo que mostrar� guitarra, el tipo de su padre
		obtTipos(orquesta);
				
		// instanceof me devuelve la clase de cada uno
		for (i=0;i<NUM_INST;i++)
	 	 if (orquesta[i] instanceof Piano)
	 	 	System.out.println("Piano ");
	 	 else if (orquesta[i] instanceof Saxofon)
	 	 	System.out.println("Saxofon ");
	 	 else if (orquesta[i] instanceof Guzla)
	 	 	System.out.println("Guzla ");
	 	 else if (orquesta[i] instanceof Ukelele)
	 	 	System.out.println("Ukelele ");	
	 	 else if (orquesta[i] instanceof Guitarra)
	 	 	System.out.println("Guitarra ");
	 	  
    }	
}
