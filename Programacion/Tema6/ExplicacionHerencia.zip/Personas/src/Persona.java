import java.util.*;

public class Persona {
	private String nif;
	private String nombre;

	public Persona() {
		System.out.println("Ejecutando el constructor por defecto de Persona");
	}

	public Persona(String nif, String nombre) {
		this.nif = nif;
		this.nombre = nombre;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void leer(Scanner sc) {

		System.out.print("Nif: ");
		nif = sc.nextLine();
		System.out.print("Nombre: ");
		nombre = sc.nextLine();

	}

	public String toString() {
		return " Nif " + nif + " Nombre: " + nombre;
	}
}
