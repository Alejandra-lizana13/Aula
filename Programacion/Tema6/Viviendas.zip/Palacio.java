public class Palacio extends Vivienda{
  private int habitaciones;

  public Palacio(int unosMetrosc, String unaCalle, int unNumero, int unasHabitaciones) {
   super(120, unaCalle, unNumero);
   habitaciones = unasHabitaciones;
 }

 public int getHabitaciones(){
   return this.habitaciones;
 }

 public void setHabitaciones(int unasHabitaciones){
    this.habitaciones = unasHabitaciones;
  }

 public String toString(){
		return super.toString() + " Habitaciones " + habitaciones;
 }
}
