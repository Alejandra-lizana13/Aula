
import java.util.*;

class Main{	
	public static final int MAX_OPC=7;

	static int menu(int tope_op, Scanner sc)
	{
		int opcion_menu;
		
		System.out.println();
	    System.out.println("\tOpcion 1- Insertar vivienda");
		System.out.println("\tOpcion 2- Insertar chalet");
		System.out.println("\tOpcion 3- Insertar palacio");
		System.out.println("\tOpcion 4- Mostrar viviendas");
		System.out.println("\tOpcion 5- Mostrar palacios");
		System.out.println("\tOpcion 6- Borrar vivienda");
		System.out.println("\tOpcion 7- Salir");
		do
		{
			System.out.print("\n\n\tElija opcion:");
			opcion_menu=sc.nextInt();
		} while (opcion_menu  < 1 || opcion_menu > tope_op);
		sc.nextLine();		
	    return opcion_menu;
	}
	
	static void miGetch(){
		try{
	          System.in.read();
	    }
	    catch(Exception e){}
	}
	
	public static void main(String args[]){		
	   int opcion=0;
	   Viviendas oViviendas=new Viviendas();
	   
	   Scanner sc = new Scanner(System.in);
	   
	   while (opcion != MAX_OPC)
		{
			opcion = menu(MAX_OPC, sc);		
			switch (opcion)
	      	{
	         case 1:	                 					 
	        	 oViviendas.anadir(LectorDatos.leerVivienda(sc));	                 
	             break;
	         case 2:					 
	        	 oViviendas.anadir(LectorDatos.leerChalet(sc));	                             
                 break;
	         case 3:	                
	        	 oViviendas.anadir(LectorDatos.leerPalacio(sc));	                 
                 break;
	          case 4:
	        	 oViviendas.listar();	
				 break;
	          case 5:	        	 
	        	 oViviendas.mostrarPalacios();	
				 break;
	          case 6:          		           		 
	        	 oViviendas.borrar(sc);	    
	             break;
	     	}
	     }
	     sc.close();
	   }
	
	
}

