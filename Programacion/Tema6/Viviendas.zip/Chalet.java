public class Chalet extends Vivienda{
  boolean jardin;

  public Chalet() {
  	jardin=false;
  }

  public Chalet(String unaCalle, int unNumero, boolean unJardin) {
    super(120, unaCalle, unNumero);
    jardin=unJardin;
 }
 
 public boolean getJardin(){
   return this.jardin;
 }

 public void setJardin(boolean unJardin){
   jardin = unJardin;
 }
 
 public String toString(){
	 
	 if (jardin) return super.toString() + " tiene jardin";
	 else return super.toString() + " no tiene jardin";
		
		
}
}
