import java.util.Scanner;

public class LectorDatos {
	public static Vivienda leerVivienda(Scanner s){          
		 System.out.println("INSERTAR VIVIENDA");
		 System.out.println("Metros:");
		 int metros=s.nextInt();
		 System.out.println("Calle:");
		 s.nextLine();
		 String calle=s.nextLine();
		 System.out.println("Numero:");
		 int numero=s.nextInt();

		 Vivienda vivienda = new Vivienda(metros, calle, numero); ;
		 
		 return vivienda;
	 }
	
	public static Chalet leerChalet(Scanner s){
		 
		 boolean jardin = false;
		
		 System.out.println("INSERTAR CHALET");
		 System.out.println("Calle:");
		 String calle=s.nextLine();
		 System.out.println("Numero:");
		 int numero=s.nextInt();
		 System.out.println("Tiene jardin (S/N):");
		 String tieneJardin=s.next().toUpperCase();
		 
		 if (tieneJardin.equals("S"))	jardin=true;
		 
		 Chalet chalet = new Chalet(calle, numero, jardin);
		 
		 return chalet;
	 }
	
	 public static Palacio leerPalacio(Scanner s){
		 System.out.println("INSERTAR PALACIO");
		 System.out.println("Metros:");
		 int metros=s.nextInt();
		 System.out.println("Calle:");
		 s.nextLine();
		 String calle=s.nextLine();
		 System.out.println("Numero:");
		 int numero=s.nextInt();
		 System.out.println("Numero de habitaciones:");
		 int nHab=s.nextInt();
		 
		 Palacio pala = new Palacio(metros,calle,numero,nHab);
		 
		 return pala;
	 }
}
