public class Vivienda {
  private int metrosc;
  private String calle;
  private int numero;


public Vivienda() {
        metrosc = 0;
        calle = "";
        numero = 0;
  }
public Vivienda(int unosMetrosc, String unaCalle, int unNumero) {
          metrosc = unosMetrosc;
          calle = unaCalle;
          numero = unNumero;
    }

public String getCalle(){
  return this.calle;
}

public void setCalle(String unaCalle){
  calle = unaCalle;
}
public int getMetrosc(){
  return this.metrosc;
}

public void setMetrosc(int unosMetrosc){
  metrosc = unosMetrosc;
}
public int getNumero(){
  return this.numero;
}

public void setNumero(int unNumero){
  numero = unNumero;
}

public String toString(){
	return "Metros " + metrosc + " Calle " + calle + " N�mero " + numero;
}

}
