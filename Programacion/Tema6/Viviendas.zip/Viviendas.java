import java.util.*;

public class Viviendas
{
	private ArrayList <Vivienda> arViviendas;
	
	public Viviendas()
	{
		arViviendas=new ArrayList <Vivienda>();
	}
	
	public void anadir(Vivienda nuevo)
	{
		arViviendas.add(nuevo);
	}
	
	/*
	public void borrar(Scanner s)
	{
		System.out.println("BORRAR VIVIENDA");
		System.out.println("Introduce calle:");
		String calle =s.nextLine();
		System.out.println("Introduce n�mero de la calle:");
		int numero=s.nextInt();	
		for(int i=0;i<arViviendas.size();i++)
		{
			if ( numero== arViviendas.get(i).getNumero() && calle.equals(arViviendas.get(i).getCalle())    )
				arViviendas.remove(i);
		}
		// Como solo se borra una funciona, pero mejor con Iterator
	}
	*/
	
	public void borrar(Scanner s)
	{
		System.out.println("BORRAR VIVIENDA");
		System.out.println("Introduce calle:");
		String calle =s.nextLine();
		System.out.println("Introduce numero de la calle:");
		int numero=s.nextInt();	
		Iterator <Vivienda> it = arViviendas.iterator();
		while (it.hasNext()) {
			if ( numero == ((Vivienda)it).getNumero() && calle.equals(((Vivienda)it).getCalle() ))
				it.remove();
		}
		
	}
	
	public void listar()
	{
		if (arViviendas.size()>0){
			for(int i=0;i<arViviendas.size();i++)
			{			
				if (arViviendas.get(i) instanceof Chalet)
					System.out.println("CHALET");
				else if (arViviendas.get(i) instanceof Palacio)
					System.out.println("PALACIO");
				else if (arViviendas.get(i) instanceof Vivienda)
					System.out.println("VIVIENDA");
				System.out.println(arViviendas.get(i));
				System.out.println("El elemento " + i + " es un "+ arViviendas.get(i).getClass().toString());
				System.out.println();
			}
			System.out.println();
	    }
		else System.out.println("No hay viviendas.");
	}
	
	public ArrayList<Vivienda> listaViviendas(){
		return arViviendas;
	}
	
	public void mostrarPalacios()
	{
		int c=0;
		
		System.out.println("PALACIOS");
		for(int i=0;i<arViviendas.size();i++)
		{
			if (arViviendas.get(i) instanceof Palacio){
				System.out.println(arViviendas.get(i));
				c++;
			}				
		}		
		if (c==0) System.out.println("No hay palacios.");		
	}
	
	
}