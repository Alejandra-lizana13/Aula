import java.util.*;

public class TalleresApp {

	public static final int MAX_OPC = 5;

	// MENU
	static int menu(int tope_op, Scanner sc) {
		int opcion_menu;

		System.out.println();
		System.out.println("\t1. Crear array con dos talleres.");
		System.out.println("\t2. Introducir un taller.");
		System.out.println("\t3. Dar de alta coche.");
		System.out.println("\t4. Imprimir los talleres y sus coches.");
		System.out.println("\t5. Salir.");
		do {
			System.out.print("\n\n\tElija opcion:");
			opcion_menu = Integer.parseInt(sc.nextLine());
		} while (opcion_menu < 1 || opcion_menu > tope_op);

		return opcion_menu;
	}

	// PROGRAMA PRINCIPAL
	public static void main(String args[]) {
		int opcion = 0;
		Scanner sc = new Scanner(System.in);
		Talleres gTalleres = null;
		Taller unTaller;
		Coche unCoche;

		while (opcion != MAX_OPC) {
			opcion = menu(MAX_OPC, sc);
			switch (opcion) {
			case 1:
				// Crear array con dos talleres
				if (gTalleres != null)
					System.out.println("\nYa existe el array de talleres.");
				else {
					gTalleres = new Talleres();
					System.out.println("\nArray de talleres creado correctamente.");
				}

				break;
			case 2:
				// Introducir un taller
				if (gTalleres != null) {
					if (gTalleres.devNumTalleres() < Talleres.NTALLERES) {
						unTaller = Lector.rellenarTaller(sc);
                        if (unTaller != null)
						    gTalleres.introducirTaller(unTaller);
                        else 
                            System.out.print("No se ha podido crear el taller.\n");
					} else
						System.out.print("No se pueden introducir talleres.\n");
				} else
					System.out.print("Tiene que crear primero un array de talleres (OPCION 1).\n");

				break;
			case 3:
				// Dar de alta coche
				if (gTalleres != null && gTalleres.devNumTalleres() == Talleres.NTALLERES) {
					System.out.print("En qu� taller quiere dar de alta el coche (1 o 2): ");
					int idTaller = Integer.parseInt(sc.nextLine());
					if (idTaller == 1 || idTaller == 2 ) {
						unCoche = Lector.rellenarCoche(sc);
                        //
						gTalleres.introducirCoche(idTaller, unCoche);
					}
					else
						System.out.println("no es un taller v�lido");
				} else
					System.out.println(
							"Tiene que rellenar los " + Talleres.NTALLERES + " talleres para poder introducir coches.");
				break;
			case 4:
				// Imprimir los talleres
				if (gTalleres != null && gTalleres.devNumTalleres() == Talleres.NTALLERES)
					System.out.println(gTalleres);
				else
					System.out.println("Tiene que introducir todos los datos para que sea posible la impresion.");
				break;
			}
		}

		sc.close();
	}
}
