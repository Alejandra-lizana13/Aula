public class Triangulo {

  private Punto vertice1;
  private Punto vertice2;
  private Punto vertice3;

  public Triangulo(Punto vertice1, Punto vertice2, Punto vertice3) {
    this.vertice1 = vertice1;
    this.vertice2 = vertice2;
    this.vertice3 = vertice3;
  }

  public double[] calcularLongitudLados() {
    double longitudLados[] = new double[3];

    // longitud 1->2
    longitudLados[0] = vertice1.calcularDistancia(vertice2);
    // longitud 2->3
    longitudLados[1] = vertice2.calcularDistancia(vertice3);
    // longitud 3->1
    longitudLados[2] = vertice3.calcularDistancia(vertice1);

    return longitudLados;
  }
}
