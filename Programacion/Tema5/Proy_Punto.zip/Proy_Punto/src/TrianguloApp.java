
public class TrianguloApp {
	  public static void main(String args[]) {

		    // Comprobar el numero de argumentos (el nombre de programa m�s las dos
		    // coordenadas)
		    if (args.length != 6) {
		      System.out.println("Uso:");
		      System.out.println("  java PruebaTriangulo x1 y1 x2 y2 x3 y3");
		      System.out.println("donde (xi,yi) son las cooordenadas de cada vertice del triangulo.");
		      return;
		    }

		    // Manejador de excepciones
		    try {
		      double x1 = Double.parseDouble(args[0]);
		      double y1 = Double.parseDouble(args[1]);
		      double x2 = Double.parseDouble(args[2]);
		      double y2 = Double.parseDouble(args[3]);
		      double x3 = Double.parseDouble(args[4]);
		      double y3 = Double.parseDouble(args[5]);

		      // Se crean los tres vertices y el triangulo
		      Punto v1 = new Punto(x1, y1);
		      Punto v2 = new Punto(x2, y2);
		      Punto v3 = new Punto(x3, y3);
		      Triangulo t = new Triangulo(v1, v2, v3);

		      // Presentacion de la informacion
		      /*System.out.println("El triangulo tiene como vertices " + v1.toString()
		          + ", " + v2.toString() + ", " + v3.toString());*/
		      System.out.println("El triangulo tiene como vertices " + v1
	          + ", " + v2 + ", " + v3);
		      
		      double[] longitudLados = t.calcularLongitudLados();
		      
		      /*System.out.println("Sus lados miden " + longitudLados[0] + ", "
		          + longitudLados[1] + ", " + longitudLados[2]);*/
		      System.out.println("Sus lados miden:");
		      for (int i = 0; i < longitudLados.length; i++) {
		    	  System.out.print(" " + longitudLados[i]);
		    	  
		      }
		      
		    } catch (Exception e) {
		      System.out.println("Error en los argumentos de la linea de comandos.");
		      return;
		    }

		  }
}
