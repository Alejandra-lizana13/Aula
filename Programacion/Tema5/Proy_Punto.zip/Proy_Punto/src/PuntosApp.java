import java.util.Scanner;

public class PuntosApp {
	 public static void main(String args[]) {
		 	// Comprobar el numero de argumentos (el nombre de programa m�s las dos coordenadas)
		    if (args.length != 2) {
		      System.out.println("Uso:");
		      System.out.println("  java Prueba x y");
		      System.out.println("donde x e y son las cooordenadas de un punto en el espacio.");
		      
		      return;
		    }
		    
		    		    
		    // Manejador de excepciones
		    try {
		      double x = Double.parseDouble(args[0]);
		      double y = Double.parseDouble(args[1]);

		      Punto p = new Punto(x, y);
		      
		      System.out.println("El punto es " + p.toString());
		      System.out.println("Su distancia al origen es " + p.distanciaAlOrigen());
		      System.out.println("Su coordenada x es " + p.getX()
		          + " y su coordenada y es " + p.getY());
		      
		      System.out.println("Usando toString() " + p);
		      
		      System.out.println("Esta ubicado en el cuadrante "
		          + p.calcularCuadrante());
		      
		      //Creamos array de puntos:
		      
		      /*Punto[] arrayPuntos = new Punto[5];
		      arrayPuntos[0] = new Punto(1, 1);
		      arrayPuntos[1] = new Punto(5, 3);
		      arrayPuntos[2] = new Punto(10, 10);
		      arrayPuntos[3] = new Punto(-3, 2);
		      arrayPuntos[4] = new Punto(-4, -5);*/
		      
		      //Cambiar para pedir 5 puntos al usuario e ir llenando el array
		      
		      Scanner teclado = new Scanner(System.in);
		      
		      System.out.println("Introduce n�mero de puntos: ");
	    	  
		      int n = teclado.nextInt();
		      Punto[] arrayPuntos = new Punto[n];
		      double cx, cy;
		      
		      for (int i = 0; i < arrayPuntos.length; i++) {
		    	  System.out.println("Introduce coordenada x ");
		    	  cx = teclado.nextDouble();
		    	  System.out.println("Introduce coordenada x ");
		    	  cy = teclado.nextDouble();
		    	  arrayPuntos[i] = new Punto(cx, cy);
		      }
		      
		      teclado.close();

		      for (int i = 0; i < arrayPuntos.length; i++) {
		        System.out.println("Su distancia al punto " + arrayPuntos[i]
		            + " es " + p.calcularDistancia(arrayPuntos[i]));
		      }
		      
		      System.out.println("El punto mas cercano es "
		          + p.calcularMasCercano(arrayPuntos));
		      
		    } catch (NumberFormatException e) {
		      System.out.println("Error en los argumentos de la l�nea de comandos.");
		    }
		  }
	
}
