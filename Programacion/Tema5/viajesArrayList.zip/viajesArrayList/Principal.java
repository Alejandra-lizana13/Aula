package viajesArrayList;
import java.util.*;
public class Principal{
	final static int NUMVIAJES=3;

	public static void main(String args[]){		
		Scanner sc=new Scanner(System.in);
		int i=0;

		Trayecto recorrido = new Trayecto();
		
		while (i<NUMVIAJES){
			System.out.println("\nViaje " + i);
			System.out.println("Introduce origen del viaje");
			String origen = sc.nextLine();
			System.out.println("Introduce destino del viaje");
			String destino = sc.nextLine();
			System.out.println("Introduce kilometros");
			double km = Double.parseDouble(sc.nextLine());
						
			recorrido.addTrayecto(new Viaje(origen, destino, km));	
			i++;

		}
		
		sc.close();
		Viaje total = recorrido.recorridoTotal();
		if (total != null)
			System.out.println("\nTrayecto total " + total);
		else
			System.out.println("\nEl recorrido no permite union de trayectos.");
				
	}
}