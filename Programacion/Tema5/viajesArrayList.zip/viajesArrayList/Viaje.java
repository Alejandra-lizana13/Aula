package viajesArrayList;
public class Viaje {
	private String origen;
	private String destino;
	private double distancia;
	
	public Viaje (String orig, String dest, double distan){
		origen = orig;
		destino = dest;
		distancia = distan;
	}
	public String getOrigen() {
		return origen;
	}
	
	public String getDestino() {
		return destino;
	}
	
	public double getDistancia() {
		return distancia;
	}
	
	public void setOrigen(String origen) {
		this.origen = origen;
	}
	
	public void setDestino(String destino) {
		this.destino = destino;
	}
	
	public void setDistancia(double distancia) {
		this.distancia = distancia;
	}
	
	public Viaje uneViaje(Viaje v) {
		Viaje nuevoViaje;
	
		if (destino.compareTo(v.origen)==0)
			nuevoViaje = new Viaje(origen, v.destino, distancia+v.distancia);
	    else
	    	nuevoViaje = new Viaje(origen, v.destino, -1);
	    	
	   return nuevoViaje;
	}
	
	public String toString(){
		
		return "\nOrigen " + origen + "\nDestino " + destino + "\nDistancia " +
		distancia;
		
	}
	
}