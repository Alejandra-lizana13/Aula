package viajesArrayList;

import java.util.ArrayList;

public class Trayecto {
	ArrayList<Viaje> trayecto;
	
	public Trayecto() {
		trayecto = new ArrayList<Viaje>();
	}
	
	public void addTrayecto(Viaje v) {
		trayecto.add(v);
	}
	
	public Viaje dameViaje(int pos ) {
		return trayecto.get(pos);
	}
	
	public double dameTam() {
		return trayecto.size();
	}
	
	public Viaje recorridoTotal() {
	Viaje nuevoTray =null;
	boolean posible=true;
	// Recorremos el array uniendo viajes
	nuevoTray = trayecto.get(0);
	for (int i=1; i<trayecto.size() && posible;i++){			
		
		nuevoTray = nuevoTray.uneViaje(trayecto.get(i));
		if (nuevoTray.getDistancia() == -1)	posible = false;		
		System.out.println("\nNuevo Trayecto -- desarrollo solo " + nuevoTray);
		
	}
	
	if (posible)
		//System.out.println("\nTrayecto total " + nuevoTray);
		return nuevoTray;
	else
		//System.out.println("\nEl recorrido no permite union de trayectos.");
		return null;
	}
}
