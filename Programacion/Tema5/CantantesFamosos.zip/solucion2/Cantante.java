package solucion2;
import java.util.ArrayList;
public class Cantante
{
	private String nombre;
	private ArrayList<Disco> discografia;

public Cantante(String n)//otro 2 parametro discos param con esto en el main puedo hacerlo todo junto
{
	nombre=n;
	discografia = new ArrayList<Disco>();

}

 //Metodo asignar discos al cantante, agregara discos
public void AsignarDisco(Disco c)
{
	if(discografia.add(c))
	{
		System.out.println("Disco agregado");
	}
	else
	{
		System.out.println("Disco no agregado");
	}
}

public String getNombre()
{
	return nombre;
}

public ArrayList<Disco> getDiscos()
{
	return discografia;
}

public String toString()
{
	return "Nombre: " + nombre   + "\n" + this.discografia;
}

}