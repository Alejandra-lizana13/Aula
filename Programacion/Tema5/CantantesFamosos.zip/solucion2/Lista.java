package solucion2;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Lista
{
   //Atributos
	private ArrayList<Cantante> listaC;

    //Metodos
public Lista(){
	listaC =new ArrayList<Cantante>();
}

public ArrayList<Cantante> devLista(){
	return listaC;
}

public Cantante rellenarCantante(Scanner sc){
	Disco disco;
	String titulo, continuar;
	int cant;
	
	System.out.println("Introduzca el nombre del cantante");
	String nombre=sc.nextLine();
	Cantante unCantante = new Cantante(nombre);
	do {           
        System.out.println("Introduce t�tulo de disco: ");
        titulo = sc.nextLine();
        System.out.println("Introduce n�mero de discos vendidos: ");
        cant = sc.nextInt();
        disco = new Disco(titulo, cant);
        unCantante.AsignarDisco(disco);
        System.out.println("�Deseas agregar otro disco de este cantante (S/N)?");
        continuar = sc.next();
        sc.nextLine();
    } while (continuar.equalsIgnoreCase("s"));
	
	return unCantante;
}

public void guardarCantante(Cantante c)
{
	if(listaC.add(c))
	{
		System.out.println("El cantante ha sido guardado");
	}
	else
	{
		System.out.println("El cantante no ha sido guardado");
	}
}


public void eliminarCantante(String nomCant)
{
   // CREAMOS EL ITERADOR
	Cantante eliminado=null;

	Iterator<Cantante> it=listaC.iterator();
	int comprobar=0;
	while(it.hasNext())
	{
		Cantante c = it.next();
	
	   //comparamos el mismo objeto en este caso Cantante, y asi sabr� cu�l eliminar
		if (c.getNombre().equals(nomCant))
		{
			eliminado=c;
			it.remove();
			comprobar++;
		}
	}
	if(comprobar>0)
		System.out.println("Se ha eliminado el cantante: \n " + eliminado);
	else
		System.out.println("No se ha encontrado el cantante: \n " + nomCant);
}

// Modificar
public void listarCantantesDiscos() {
    Cantante cantante;
    Disco disco;
    
    Iterator<Cantante> it = listaC.iterator();
    while (it.hasNext()) {
        cantante = it.next();
        System.out.println("Cantante: " + cantante.getNombre());
        ArrayList<Disco> listaD = cantante.getDiscos();
        Iterator<Disco> it2 = listaD.iterator();
        
        while (it2.hasNext()) {
        	disco = it2.next();       	
        	System.out.println(disco);
        }
    }
}

public void listarDiscoMasVendido() {
    Cantante cantante;
    Disco disco, discoMax=null;
    
    Iterator<Cantante> it = listaC.iterator();
    while (it.hasNext()) {
        cantante = it.next();
        System.out.println("Cantante: " + cantante.getNombre());
        ArrayList<Disco> listaD = cantante.getDiscos();
        Iterator<Disco> it2 = listaD.iterator();
        
        int max = -1;
        while (it2.hasNext()) {
        	disco = it2.next();
        	if (disco.getDVendidos() > max) {
        		max = disco.getDVendidos();
        		discoMax = disco;
        	}      	
        }
        System.out.println(" Disco m�s vendido: " + discoMax);
    }
}


}