package solucion1;
import java.util.ArrayList;
import java.util.Iterator;

public class ListaCantantesFamosos {

    ArrayList<CantanteFamoso> cantantes;

    public ListaCantantesFamosos() {
        cantantes = new ArrayList<CantanteFamoso>();
    }

    public void agregarCantanteFamoso(CantanteFamoso Cantante) {
        cantantes.add(Cantante);
    }

    public void listarCantantes() {
        //CantanteFamoso cantante;
        Iterator<CantanteFamoso> continuar = cantantes.iterator();
        while (continuar.hasNext()) {
            //cantante = continuar.next();
           
            /*System.out.print("Cantante: " + cantante.getNombre());
            System.out.println("        Discos con mas ventas: " + cantante.getDiscoConMasVentas());*/
        	System.out.println(continuar.next());
        }
    }

}