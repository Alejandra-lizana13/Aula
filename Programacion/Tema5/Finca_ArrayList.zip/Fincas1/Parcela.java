public class Parcela {
	int metros;
	String tipo_explotacion;
	
	public Parcela (int _metros,String _tipo_explotacion){
		metros = _metros;
		tipo_explotacion = _tipo_explotacion;
	}	
	
	public String toString(){
		String aux;
		
		aux = "\n> PARCELA:";
		aux += "\nMetros cuadrados: "+metros;
		aux += "\nTipo de explotaci�n: "+tipo_explotacion;
		
		return aux;
	}
}