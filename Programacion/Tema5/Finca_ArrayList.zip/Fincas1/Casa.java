public class Casa {
	int metros;
	int plantas;
	int habitaciones;
	
	public Casa (int _metros,int _plantas, int _habitaciones){
		metros = _metros;
		plantas = _plantas;
		habitaciones = _habitaciones;		
	}
	
	public String toString(){
		String aux;
		
		aux = "\n> CASA:";
		aux += "\nMetros cuadrados: "+metros;
		aux += "\nNumero de plantas: "+plantas;
		aux += "\nNumero de habitaciones: "+habitaciones;
		
		return aux;
	}
}