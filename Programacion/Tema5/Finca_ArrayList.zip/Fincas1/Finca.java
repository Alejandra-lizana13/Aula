public class Finca {
	String nombre;
	int metros;
	Casa miCasa;
	Parcela miParcela;
	
	public Finca (String _nombre,int _metros, Casa _miCasa, Parcela _miParcela){
		nombre = _nombre;
		metros = _metros;
		miCasa = _miCasa;
		miParcela = _miParcela;
	}
	
	
	public String toString(){
		String aux;
		
		aux = "\n> FINCA:";
		aux += "\nNombre: " + nombre;
		aux += "\nMetros: " + metros;
		
		//return aux + miCasa.toString() + miParcela.toString() ;
		return aux + miCasa + miParcela;
	}
}