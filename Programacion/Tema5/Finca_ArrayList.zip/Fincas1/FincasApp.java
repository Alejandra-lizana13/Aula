import java.util.*;
	
public class FincasApp {
	
	public static final int MAX_OPC=4;
		
	// menu
	static int menu(int tope_op, Scanner sc)
	{
			int opcion_menu;
			
			System.out.println();
		    System.out.println("\t1. Introducir datos de las fincas.");
			System.out.println("\t2. Mostrar una finca dado su nombre.");
			System.out.println("\t3. Mostrar todas las fincas.");
			System.out.println("\t4. Salir.");
			do
			{
				System.out.print("\n\n\tElija opcion:");
				opcion_menu=Integer.parseInt(sc.nextLine());
			} while (opcion_menu  < 1 || opcion_menu > tope_op);
			
		    return opcion_menu;
	}
		
	// Rellenar Casa
	
	static Casa rellenarCasa (Scanner sc){
		System.out.println ("> DATOS DE LA CASA:");
		System.out.print("Metros cuadrados: ");
		int m2 = Integer.parseInt(sc.nextLine());
		System.out.print("Numero de plantas: ");
		int nPlantas = Integer.parseInt(sc.nextLine());
		System.out.print("Numero de habitaciones: ");
		int nHab = Integer.parseInt(sc.nextLine());
		return new Casa(m2,nPlantas,nHab);	
	}
	
	// Rellenar Parcela
	
	static Parcela rellenarParcela (Scanner sc){
		System.out.println ("> DATOS DE LA PARCELA:");
		System.out.print("Metros cuadrados: ");
		int m2 = Integer.parseInt(sc.nextLine());
		System.out.print("Tipo de explotacion (Agricola o Ganadera): ");
		String expl = sc.nextLine();
		while (!expl.equals("Agricola") && !expl.equals("Ganadera")){
			System.out.print("Tipo de explotacion (Agricola o Ganadera): ");
			expl = sc.nextLine();
		}
		
		return new Parcela(m2,expl);	
	}
	
	// Rellenar Finca
	
	static Finca rellenarFinca (Scanner sc){
		Casa miCasa;
		Parcela miParcela;
		System.out.println ("> DATOS DE LA FINCA:");
		System.out.print("Nombre: ");
		String nomb = sc.nextLine();
		//System.out.print("Metros cuadrados: ");
		//int m2 = sc.nextInt();
		
		miCasa = rellenarCasa(sc);
		miParcela = rellenarParcela(sc);
		
		return new Finca(nomb, miCasa.metros+miParcela.metros, miCasa, miParcela);	
	}
	
	//programa principal
	public static void main (String args[]){
		Scanner sc = new Scanner (System.in);
		boolean primera = true;
		int opcion = 0;
		ArrayFincas misFincas = null;
		Finca unaFinca = null;
		
		while (opcion != MAX_OPC)
		{
			opcion = menu(MAX_OPC, sc);
			switch (opcion)
	      	{
	         case 1:
	                 //Introducimos los datos para cada finca
	              	// la primera vez creamos el objeto misFincas
	        	 	if (primera) {
	        	 		misFincas = new ArrayFincas();
	        	 		primera = false;
	        	 	}
	                unaFinca = rellenarFinca(sc);
	                if (unaFinca != null) // conviene comprobarlo cada vez
	                	 misFincas.introducirFinca(unaFinca);
	                 	             	                 
	                break;
	         case 2:
	     			 // Mostrar finca dado su nombre
	     			if (misFincas != null) {
	     			 	System.out.print("Introduzca el nombre de la finca a mostrar: ");
	                 	String nombre_finca= sc.nextLine();
	                	misFincas.mostrarFincaNombre(nombre_finca);
	     			 }
	     			 else
	     			 	 System.out.println("Debe introducir primero los datos de las fincas.");
	     			 		
	                 break;
	         case 3:
	     			 // Mostrar todas las fincas
	        	 	if (misFincas != null)	
	     			 	System.out.println(misFincas);	
	     			else
	     			 	System.out.println("Debe introducir primero los datos de las fincas.");
	     			 	
	                break;
	                 
	     	}
	     }
	     sc.close();		
	}
}
