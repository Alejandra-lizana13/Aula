import java.util.*;
public class Triangulos {
	private ArrayList<Triangulo> arrayTriangulos;
	
	/*******************************************************/
	/* Triangulos: constructor de la clase en la que se    */
	/* guarda el conjunto de tri�ngulos que se van creando */
	/*******************************************************/
	public Triangulos() {
		arrayTriangulos = new ArrayList<Triangulo>();
	}
	
	/*******************************************************/
	/* aniadir: a�ade un nuevo tri�ngulo a la colecci�n    */
	/*******************************************************/
	public void aniadir(Triangulo t) {
		arrayTriangulos.add(t);
	}
	
	/*******************************************************/
	/* dame: devuelve el tri�ngulo que ocupa la posici�n   */
	/* recibida  por par�metro en la colecci�n             */
	/*******************************************************/
	public Triangulo dame(int i) {
		return arrayTriangulos.get(i);
	}
	
	/*******************************************************/
	/* mayorAreaTriangulo: devuelve la posici�n del        */
	/* tri�ngulo que tiene mayor �rea                      */
	/*******************************************************/
	public int mayorAreaTriangulo() {
		if (arrayTriangulos.size() == 0) {
   			System.out.println("No hay ningun triangulo");
   			return -1;
		}
   		else {
   			 double max = arrayTriangulos.get(0).area();
   			 double area;
	         int mayor=0;
	         for (int i=1; i<arrayTriangulos.size(); i++){
	            	 if (arrayTriangulos.get(i)!= null){  
	            		 area = arrayTriangulos.get(i).area();
	   	        	     if(area > max){
	   	        		     max=area;
	   	        		     mayor=i;
	   	        	     }
	            	 }
	         }	
	         return mayor;
   		}
    }
	
	/*******************************************************/
	/* mayorAreaTriangulo_O: devuelve el tri�ngulo que     */
	/*                       tiene mayor �rea              */
	/*******************************************************/
	public Triangulo mayorAreaTriangulo_O() {
		if (arrayTriangulos.size() == 0) {
   			System.out.println("No hay ningun triangulo");
   			return null;
		}
   		else {
   			 double max = arrayTriangulos.get(0).area();
   			 double area;
	         int mayor=0;
	         for (int i=1; i<arrayTriangulos.size(); i++){
	        	 if (arrayTriangulos.get(i)!= null){  
            		 area = arrayTriangulos.get(i).area();
   	        	     if(area > max){
   	        		     max=area;
   	        		     mayor=i;
   	        	     }
            	 }
	         }	
	         return arrayTriangulos.get(mayor);
   		}
    }
	
	/*******************************************************/
	/* menorPeriTriangulo: devuelve la posici�n del        */
	/* tri�ngulo que tiene menor per�metro                 */
	/*******************************************************/
    public int menorPeriTriangulo() {
    	if (Triangulo.getNT() == 0) {
   			System.out.println("No hay ning�n triangulo");
   			return -1;
		}
    	else {     
    	    	double min=arrayTriangulos.get(0).perimetro();
    	    	double peri;
                int menor=0;
                for(int j=1; j<Triangulo.getNT(); j++){
                    	 if (arrayTriangulos.get(j)!= null){ 
                    		 peri = arrayTriangulos.get(j).perimetro();
                    		 if(peri < min){
                    			 min=peri;
                    			 menor=j;
                    		 }
                    	 }
                 }
                return menor;  
   		}
    	  	
    }
    
    /*******************************************************/
	/* mostrarUnTriangulo: devuelve la posici�n del        */
	/* tri�ngulo que tiene menor per�metro                 */
	/*******************************************************/
    public void mostrarUnTriangulo(Scanner sc) {
        int n;
        
    		// Mostramos todos los triangulos antes de pedir cual se quiere 
        	//mostrarTriangulos(arrayTriangulos);
        	System.out.println("Introducir triangulo a mostrar. Puede haber hasta " + arrayTriangulos.size() + " triangulos.");
            n=sc.nextInt();
            if (n<=0 || n>arrayTriangulos.size() || arrayTriangulos.get(n-1) == null) 
          	   System.out.println("Ese tri�ngulo no existe.");    		      
            else{
    	    	   System.out.println("TRIANGULO "+n);
    	    	   // Utilizando el metodo toString()
    		       System.out.print(arrayTriangulos.get(n-1));		
    		       System.out.printf( "%nArea %1$.2f %nPerimetro %2$.2f%n", arrayTriangulos.get(n-1).area(), arrayTriangulos.get(n-1).perimetro());
    	           System.out.println();  
    	     }	
        }
        
    /*******************************************************/
	/* mostrarTriangulos: escribe los datos de todos los   */
    /* 					  tri�ngulos                       */
	/*******************************************************/
        public void mostrarTriangulos() {
    	    for(int j=0;j<Triangulo.getNT();j++){
    	   		if (arrayTriangulos.get(j) != null) {
    	         System.out.println("\nTRIANGULO "+(j+1)+"\nBase "+ arrayTriangulos.get(j).getBase()+"\nAltura "+arrayTriangulos.get(j).getAltura());
    	         //System.out.println("   Area "+arrayTriangulos.get(j).area()+"\n   Perimetro "+arrayTriangulos.get(j).perimetro());
    	         System.out.printf( "Area %1$.2f %nPerimetro %2$.2f%n%n", arrayTriangulos.get(j).area(), arrayTriangulos.get(j).perimetro());
    	   		}
    	    }
        }
	
}
