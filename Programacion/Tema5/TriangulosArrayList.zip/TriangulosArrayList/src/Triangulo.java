public class Triangulo {
    private double b, h;
    private static int num_T=0;
    
    Triangulo(int b, int h){
    	this.b=b;
    	this.h=h;
    	num_T++;
    }
    
	/*******************************************************/
	/* getNT: devuelve el n�mero de tri�ngulos creados     */
	/*******************************************************/
    public static int getNT(){
    	return num_T;
    }
    
	/*******************************************************/
	/* area: devuelve el �rea de un tri�ngulo              */
	/*******************************************************/
    public double area(){
    	double a;
    	a=(double)b*h/2;
    	return a;
    }
    
	/*******************************************************/
	/* perimetro: devuelve el per�metro de un tri�ngulo    */
	/*******************************************************/
    public double perimetro(){
    	double p;
    	double x=Math.sqrt(Math.pow((b/2.0),2)+Math.pow(h, 2));
    	p=2*x+b;
    	return p;
    }
    
	/*******************************************************/
	/* setBase: modifica la base de un tri�ngulo           */
	/*******************************************************/
    public void setBase (int base){
    	b = base;
    }
    
	/*******************************************************/
	/* setAltura: modifica la altura de un tri�ngulo       */
	/*******************************************************/
    public void setAltura(int altura){
    	h = altura;
    }
    
	/*******************************************************/
	/* getBase: devuelve la base de un tri�ngulo           */
	/*******************************************************/
    public double getBase(){
    	return b;
    }
    
	/*******************************************************/
	/* getAltura: devuelve la altura de un tri�ngulo       */
	/*******************************************************/
    public double getAltura(){
    	return h;
    }
    
	/*******************************************************/
	/* getLadoIgual: devuelve el valor del lado igual      */
	/*******************************************************/
    public double getLadoIgual(){   	
    	return(Math.pow((b/2), 2) + Math.pow(h,2));    	
    }
    
    /*********************************************************/
	/* toString: convierte en cadena el objeto para imprimir */
	/*********************************************************/
    public String toString(){
    	return ("\nBase " + b + "\nAltura " + h);
    }
}